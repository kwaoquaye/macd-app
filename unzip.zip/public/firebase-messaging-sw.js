importScripts("https://www.gstatic.com/firebasejs/9.6.1/firebase-app-compat.js");
importScripts("https://www.gstatic.com/firebasejs/9.6.1/firebase-messaging-compat.js");

firebase.initializeApp({
  apiKey: "AIzaSyCdNIjD_xA9f8mTE3OrFL-Y8rN4t1uxnHY",
  authDomain: "macd-futures.firebaseapp.com",
  projectId: "macd-futures",
  storageBucket: "macd-futures.firebasestorage.app",
  messagingSenderId: "352617415284",
  appId: "1:352617415284:web:882d0f7b7fb00b17d78721",
  measurementId: "G-RJMDD83EXP"
});

const messaging = firebase.messaging();

messaging.onBackgroundMessage((payload) => {
  const { title, body } = payload.notification;
  self.registration.showNotification(title, {
    body,
    icon: "/logo.png"
  });

  self.addEventListener('notificationclick', function (event) {
  console.log('[Service Worker] Notification click received:', event);

  event.notification.close();

  // Focus existing tab if open, or open new one
  event.waitUntil(
    clients.matchAll({ type: 'window', includeUncontrolled: true }).then(clientList => {
      for (const client of clientList) {
        // If app already open in a tab
        if (client.url === '/' && 'focus' in client) {
          return client.focus();
        }
      }

      // Otherwise open the app
      if (clients.openWindow) {
        return clients.openWindow('/');
      }
    })
  );
});

});
