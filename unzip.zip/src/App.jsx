import { useEffect } from "react";
import { requestPermission, listenForMessages } from "./notifications";
import { messaging, onMessage } from './firebase';

function App() {
  useEffect(() => {
    requestPermission();
    listenForMessages();

     const unsubscribe = onMessage(messaging, (payload) => {
    console.log('Message received in foreground: ', payload);
    alert(`${payload.notification.title}: ${payload.notification.body}`);
  });

  return () => unsubscribe();
  }, []);

  return (
    <div>
      <h1>React + Vite + FCM</h1>
      <p>You’ll get notifications if allowed.</p>
    </div>
  );
}

export default App;
