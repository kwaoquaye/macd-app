// src/firebase.js
import { initializeApp } from "firebase/app";
import { getMessaging, getToken, onMessage } from "firebase/messaging";

import { getAnalytics } from "firebase/analytics";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries
// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyCdNIjD_xA9f8mTE3OrFL-Y8rN4t1uxnHY",
  authDomain: "macd-futures.firebaseapp.com",
  projectId: "macd-futures",
  storageBucket: "macd-futures.firebasestorage.app",
  messagingSenderId: "352617415284",
  appId: "1:352617415284:web:882d0f7b7fb00b17d78721",
  measurementId: "G-RJMDD83EXP"
};
// Initialize Firebase
const app = initializeApp(firebaseConfig);
const analytics = getAnalytics(app);

const messaging = getMessaging(app);

export { messaging, analytics, getToken, onMessage };
