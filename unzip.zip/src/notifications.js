import { messaging, getToken, onMessage } from "./firebase";

const VAPID_KEY = "BIin8qajqFDk31Rz_eOBla711dtLXCoQrLnKjQv7-3j_GYKF-D90T8zlwmq2xl1Mk6ZbdokB1drEah9d66khHyc"; // from Firebase Console

export async function requestPermission() {
  try {
    const token = await getToken(messaging, { vapidKey: VAPID_KEY });
    if (token) {
      await fetch("https://macd-fcm-connect-api-latest.onrender.com/register-token", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ token }),
      });
    }
  } catch (err) {
    console.error("FCM permission error:", err);
  }
}

export function listenForMessages() {
  onMessage(messaging, (payload) => {
    console.log("Message received:", payload);
    alert(payload.notification.title + "\n" + payload.notification.body);
  });
}
