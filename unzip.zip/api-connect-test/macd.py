from flask import Blueprint, jsonify
import ccxt
import pandas as pd
import os
import requests
from datetime import datetime
macd_bp = Blueprint("macd", __name__)
# ======================
# Configurations
# ======================
EXCHANGE = ccxt.binance({
    "enableRateLimit": True,
    "options": {"defaultType": "future"}  # Binance Futures
})
SYMBOLS = ["BTC/USDT", "ETH/USDT", "BNB/USDT"]  # you can expand
TIMEFRAME = "15m"
# Telegram credentials (set in environment variables)
TELEGRAM_BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN")
TELEGRAM_CHAT_ID = os.getenv("TELEGRAM_CHAT_ID")
# ======================
# Utility functions
# ======================
def send_telegram(message: str):
    """Send message to Telegram Bot"""
    if not TELEGRAM_BOT_TOKEN or not TELEGRAM_CHAT_ID:
        print("Telegram not configured")
        return
    url = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMessage"
    payload = {"chat_id": TELEGRAM_CHAT_ID, "text": message}
    requests.post(url, json=payload)
def fetch_ohlcv(symbol, timeframe="15m", limit=100):
    """Fetch OHLCV candles"""
    ohlcv = EXCHANGE.fetch_ohlcv(symbol, timeframe=timeframe, limit=limit)
    df = pd.DataFrame(
        ohlcv, columns=["time", "open", "high", "low", "close", "volume"]
    )
    df["time"] = pd.to_datetime(df["time"], unit="ms")
    return df
def calculate_macd(df):
    """Calculate MACD values"""
    df["ema12"] = df["close"].ewm(span=12).mean()
    df["ema26"] = df["close"].ewm(span=26).mean()
    df["macd"] = df["ema12"] - df["ema26"]
    df["signal"] = df["macd"].ewm(span=9).mean()
    return df
def check_signal(df):
    """Check MACD crossover"""
    if len(df) < 2:
        return None
    latest, prev = df.iloc[-1], df.iloc[-2]
    if prev["macd"] < prev["signal"] and latest["macd"] > latest["signal"]:
        return "BUY"
    elif prev["macd"] > prev["signal"] and latest["macd"] < latest["signal"]:
        return "SELL"
    return None
# ======================
# Flask Route
# ======================
@macd_bp.route("/signals", methods=["GET"])
def get_signals():
    """Return MACD signals for all configured symbols"""
    results = []
    for symbol in SYMBOLS:
        try:
            df = fetch_ohlcv(symbol, TIMEFRAME)
            df = calculate_macd(df)
            signal = check_signal(df)
            if signal:
                entry_price = df.iloc[-1]["close"]
                result = {
                    "symbol": symbol,
                    "signal": signal,
                    "entry_price": float(entry_price),
                    "time": datetime.utcnow().isoformat(),
                }
                results.append(result)
                # Send Telegram Alert
                send_telegram(f"{signal} signal on {symbol} at {entry_price}")
        except Exception as e:
            results.append({"symbol": symbol, "error": str(e)})
    return jsonify({"signals": results})
