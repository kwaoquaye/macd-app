from flask import Flask, request, jsonify
from firebase_service import initialize_firebase
from send_notification import send_push_notification
from flask_cors import CORS
import os
import ccxt
import pandas as pd
import requests
from datetime import datetime

app = Flask(__name__)
initialize_firebase()
CORS(app)  # Allow all origins — for development only!

# For demo, using in-memory token list (replace with DB for prod)
tokens = set()

@app.route("/register-token", methods=["POST"])
def register_token():
    data = request.get_json()
    token = data.get("token")
    if token:
        tokens.add(token)
        print(f"Token registered: {token}")
        return jsonify({"status": "Token registered"}), 200
    return jsonify({"error": "Token is missing"}), 400

@app.route("/send-notification", methods=["POST"])
def send_notification():
    data = request.get_json()
    title = data.get("title", "Test Notification")
    body = data.get("body", "This is a test.")

    for token in tokens:
        send_push_notification(token, title, body)

    return jsonify({"status": f"Notification sent to {len(tokens)} tokens."}), 200


# Configurations
# ======================
EXCHANGE = ccxt.binance({
    "enableRateLimit": True,
    "options": {"defaultType": "future"}  # Binance Futures
})
SYMBOLS = ["1000BONK/USDT", "1000CAT/USDT", "1000FLOKI/USDT", "1000PEPE/USDT", "1000SATS/USDT", "1000SHIB/USDT",
           "1MBABYDOGE/USDT", "AAVE/USDT", "ACE/USDT", "ACH/USDT", "ADA/USDT", "AGLD/USDT", "AGT/USDT", "AI/USDT",
           "ALGO/USDT", "ALICE/USDT", "ALT/USDT", "ANKR/USDT", "API3/USDT", "APT/USDT", "ARB/USDT", "ARPA/USDT",
           "ARU/USDT", "ASTR/USDT", "ATA/USDT", "ATH/USDT", "AUCTION/USDT", "AVAX/USDT", "AXL/USDT",
           "BABY/USDT", "BAKE/USDT", "BAN/USDT", "BAND/USDT", "BB/USDT", "BCH/USDT", "BEAMX/USDT", "BEL/USDT",
           "BICO/USDT", "BLUR/USDT", "BMT/USDT", "BNB/USDT", "BNT/USDT", "BOME/USDT", "BROCCOLI714/USDT",
           "BROCCOLIF3B/USDT", "BTC/USDT", "BU/USDT", "C98/USDT", "CATI/USDT", "CELO/USDT", "CHR/USDT", "CHZ/USDT",
           "CKB/USDT", "COMP/USDT", "COTI/USDT", "CRV/USDT", "CTSI/USDT", "CVC/USDT", "CYBER/USDT", "DASH/USDT",
           "DEEP/USDT", "DENT/USDT", "DIA/USDT", "DOGE/USDT", "DOOD/USDT", "DOT/USDT", "DUSK/USDT", "DYDX/USDT",
           "DYM/USDT","EDU/USDT", "EGLD/USDT", "ENA/USDT", "ENJ/USDT", "ENS/USDT", "EPIC/USDT", "ETC/USDT", "ETHFI/USDT",
           "ETH/USDT", "FET/USDT", "FIL/USDT", "FIO/USDT", "FLOW/USDT", "FLUX/USDT", "FXS/USDT", "GALA/USDT",
           "GAS/USDT", "GHST/USDT", "GLM/USDT", "GMX/USDT", "GOAT/USDT", "GRT/USDT", "GTC/USDT", "GUN/USDT",
           "HFT/USDT", "HIGH/USDT", "HIPPO/USDT", "HMSTR/USDT", "HOOK/USDT", "HYPER/USDT", "ICP/USDT", "ICX/USDT",
           "IDU/USDT", "ILV/USDT", "INIT/USDT", "INJ/USDT", "IOTX/USDT", "JELLYJELLY/USDT", "JOE/USDT", "JTO/USDT",
           "JUP/USDT", "KAVA/USDT", "KDA/USDT", "KNC/USDT", "LINK/USDT", "LPT/USDT", "LQTY/USDT", "LRC/USDT", "LSK/USDT",
           "MAGIC/USDT", "MANTA/USDT", "MEME/USDT", "MINA/USDT", "MOODENG/USDT", "MOVR/USDT", "MTL/USDT", "MUBARAK/USDT",
           "NEAR/USDT", "NEIRO/USDT", "NEIROETH/USDT", "NFP/USDT", "NMR/USDT", "NOT/USDT", "NTRN/USDT", "NXPC/USDT",
           "OBOL/USDT", "OGN/USDT", "OGU/USDT", "OMU/USDT", "ONDO/USDT", "ONE/USDT", "ONG/USDT", "OP/USDT",
           "ORDI/USDT", "OXT/USDT", "PAXG/USDT", "PENDLE/USDT", "PEOPLE/USDT", "PHB/USDT", "POLYX/USDT", "POWR/USDT",
           "PROMPT/USDT", "PUNDIX/USDT", "PYTH/USDT", "QNT/USDT", "QUICK/USDT", "RDNT/USDT", "RENDER/USDT", "RIF/USDT",
           "RLC/USDT", "RONIN/USDT", "ROSE/USDT", "RPL/USDT", "RUNE/USDT", "RVN/USDT", "SAFE/USDT", "SAN/USDT",
           "SANTOS/USDT", "SEI/USDT", "SFP/USDT", "SIREN/USDT", "SKL/USDT", "SKYAI/USDT", "SNX/USDT", "SOL/USDT",
           "SOON/USDT", "SPELL/USDT", "SSV/USDT", "STEEM/USDT", "STG/USDT", "STORJ/USDT", "STO/USDT", "STX/USDT",
           "SUI/USDT", "SUPER/USDT", "SWELL/USDT", "SYRUP/USDT", "TIA/USDT", "TLM/USDT", "TON/USDT", "TRB/USDT",
           "TRU/USDT", "TRX/USDT", "TU/USDT", "TUT/USDT", "TWT/USDT", "UMA/USDT", "UNI/USDT", "USTC/USDT", "UXLINK/USDT",
           "VIC/USDT", "WAL/USDT", "WAX/USDT", "WIF/USDT", "WLD/USDT", "WOO/USDT", "WU/USDT", "XAI/USDT", "XRP/USDT",
           "XVG/USDT", "XVS/USDT", "YGG/USDT", "ZIL/USDT", "ZRO/USDT", "ZRX/USDT", ]


def calculate_macd(df):
    """Calculate MACD & Signal line"""
    df["ema12"] = df["close"].ewm(span=12).mean()
    df["ema26"] = df["close"].ewm(span=26).mean()
    df["macd"] = df["ema12"] - df["ema26"]
    df["signal"] = df["macd"].ewm(span=9).mean()
    return df
def check_signal(df):
    """Check if there's a new MACD crossover"""
    if len(df) < 2:
        return None
    latest, prev = df.iloc[-1], df.iloc[-2]
    if prev["macd"] < prev["signal"] and latest["macd"] > latest["signal"]:
        return "BUY"
    elif prev["macd"] > prev["signal"] and latest["macd"] < latest["signal"]:
        return "SELL"
    return None


def fetch_ohlcv(symbol, timeframe="15m", limit=100):
    """Fetch OHLCV data from Binance Futures"""
    ohlcv = EXCHANGE.fetch_ohlcv(symbol, timeframe=timeframe, limit=limit)
    df = pd.DataFrame(
        ohlcv, columns=["time", "open", "high", "low", "close", "volume"]
    )
    df["time"] = pd.to_datetime(df["time"], unit="ms")
    return df
    
@app.route("/signals", methods=["GET"])
def get_signals():
    """Return MACD signals for all configured symbols (timeframe configurable via query param)"""
    timeframe = request.args.get("timeframe", "15m")  # default = 15m
    results = []
    for symbol in SYMBOLS:
        try:
            df = fetch_ohlcv(symbol, timeframe)
            df = calculate_macd(df)
            signal = check_signal(df)
            if signal:
                entry_price = df.iloc[-1]["close"]
                result = {
                    "symbol": symbol,
                    "signal": signal,
                    "entry_price": float(entry_price),
                    "time": datetime.utcnow().isoformat(),
                    "timeframe": timeframe
                }
                results.append(result)
                # Send Telegram Alert
                send_telegram(f"{signal} signal on {symbol} ({timeframe}) at {entry_price}")
                for token in tokens:
                    send_push_notification(token, 'Charley new futures oo', str(results))
                return jsonify({"signals": results})
        except Exception as e:
            results.append({"symbol": symbol, "error": str(e)})
            for token in tokens:
                send_push_notification(token, 'Charley error, still under construction', str(results))
            return jsonify({"signals": {"error": str(e), "details": results}})
if __name__ == "__main__":
    port = int(os.environ.get('PORT', 5000))
    app.run(host='0.0.0.0', port=port)
